const express = require('express');
const mongoose = require('mongoose');
const db = require('./models/db');
const app = express();
const path = require('path');
const router = express.Router();
const bodyParser = require('body-parser');
const feedbackSchema = require('./models/feedbackmodel');
// const feedbackRouter = require('./routes/feedbackrouter');
const PORT = process.env.PORT || 8888;
app.use(bodyParser.json());

app.listen(PORT, () => {
    console.log(`Server Started on PORT ${PORT}`)
});
app.get('/', (req, res) => {
    res.send('You are on home page');
})
app.get('/feedback', (req, res) => {
    res.send('Fill in the Feedback Form details');
});


app.post('/aboutus', (req, res) => {
    console.log(req.body)
    const feedback = new feedbackSchema(req.body);
    feedback.save();
    res.send({
        name: req.body.name,
        email: req.body.email,
        subject: req.body.subject,
        message: req.body.message
    })
});